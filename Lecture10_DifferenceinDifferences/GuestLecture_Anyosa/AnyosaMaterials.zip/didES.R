# Simulated Blood Pressure Analysis with Time-Varying Intervention Effects
 
# Load necessary libraries
library(dplyr)
library(ggplot2)
library(fixest)
library(stringr)

# Parameters
set.seed(123)  # For reproducibility
num_districts <- 10
time_periods <- 10
intervention_start <- 6
base_mean_bp <- 145
random_sd <- 5  # Standard deviation for random intercepts
time_fixed_effects <- seq(-2, 2, length.out = time_periods)  # Fixed effects for each time point

# Time-varying intervention effects
intervention_effects <- c(0, 0, 0, 0, 0, -3, -5, -8, -11, -15)

# Generate random intercepts for districts
districts <- 1:num_districts
random_intercepts <- rnorm(num_districts, mean = base_mean_bp, sd = random_sd)

# Assign intervention to 5 districts randomly
intervention_districts <- sample(districts, size = 5)

# Create the dataset
simulated_data <- expand.grid(
  district = districts,
  time = 1:time_periods
) %>%
  mutate(
    random_intercept = random_intercepts[district],
    time_fixed_effect = time_fixed_effects[time],
    intervention = ifelse(district %in% intervention_districts & time >= intervention_start, 1, 0),
    effect = intervention * intervention_effects[time],
    blood_pressure = random_intercept + time_fixed_effect + effect + rnorm(n(), mean = 0, sd = 2)  # Add noise
  ) %>%
  group_by(district) %>%
  mutate(
    treated = ifelse(district %in% intervention_districts, 1, 0),
    post = ifelse(time >= intervention_start, 1, 0)
  )

# Visualize overall data
ggplot(simulated_data, aes(x = time, y = blood_pressure, color = as.factor(treated), group = district)) +
  geom_line() +
  labs(
    title = "Simulated Blood Pressure Data with Time-Varying Intervention Effects",
    x = "Time",
    y = "Blood Pressure",
    color = "Treated"
  ) +
  theme_minimal()

# Focused comparison for 2 districts
simulated_data_bi <- simulated_data %>% filter(district %in% c(1, 6))

ggplot(simulated_data_bi, aes(x = time, y = blood_pressure, color = as.factor(treated), group = district)) +
  geom_line() +
  geom_point() +
  geom_vline(xintercept = 5.5, lty = 2) +
  labs(
    title = "Simulated Blood Pressure Data - 2 Districts",
    x = "Time",
    y = "Blood Pressure",
    color = "Treated"
  ) +
  theme_minimal()



# Add event-time variable
simulated_data_bi <- simulated_data_bi %>%
  mutate(
    event_time = time - 6)
  

# Create dummy variables for event time
event_time_dummies <- model.matrix(~ as.factor(event_time) - 1, data = simulated_data_bi)
colnames(event_time_dummies) <- paste0("event_time_", c("m5","m4","m3","m2","m1",0,1,2,3,4))
simulated_data_bi <- cbind(simulated_data_bi, event_time_dummies)

# Multiply event-time dummies by treated
interaction_terms <- as.data.frame(event_time_dummies * simulated_data_bi$treated)
colnames(interaction_terms) <- paste0(colnames(event_time_dummies), "_treated")

# Add interaction terms to the dataset
simulated_data_bi <- cbind(simulated_data_bi, interaction_terms)

# Event study regression (excluding event time = -1 as baseline)
event_study_model <- feols(
  blood_pressure ~
    event_time_m5_treated+
    event_time_m4_treated+
    event_time_m3_treated+
    event_time_m2_treated+
    event_time_0_treated+
    event_time_1_treated+
    event_time_2_treated+
    event_time_3_treated+
    event_time_4_treated | district + time,
  data = simulated_data_bi
)

# Summary of the event study model
summary(event_study_model)




# Extract coefficients and confidence intervals for visualization
event_study_results <- broom::tidy(event_study_model, conf.int = TRUE) %>%
  filter(str_detect(term, "event_time")) %>%
  mutate(
    event_time = str_extract(term, "m?\\d+"),  # Extract the number with or without 'm'
    event_time = ifelse(str_detect(event_time, "m"),  # Check if 'm' is present
                        as.numeric(str_replace(event_time, "m", "-")),  # Replace 'm' with '-' and convert
                        as.numeric(event_time))  # Otherwise, convert directly to numeric
  )

# Plot the event study results
ggplot(event_study_results, aes(x = event_time, y = estimate)) +
  geom_point() +
  geom_line() +
  geom_errorbar(aes(ymin = conf.low, ymax = conf.high), width = 0.2) +
  geom_vline(xintercept = -1, linetype = "dashed", color = "red") +
  scale_x_continuous(breaks = c(-5:4))+
  labs(
    title = "Event Study: Impact of Intervention on Blood Pressure",
    x = "Event Time (Relative to Intervention Start)",
    y = "Effect on Blood Pressure"
  ) +
  theme_minimal()





# For the complete data ---------------------------------------------------



# Add event-time variable
simulated_data <- simulated_data %>%
  mutate(
    event_time = time - 6)


# Create dummy variables for event time
event_time_dummies <- model.matrix(~ as.factor(event_time) - 1, data = simulated_data)
colnames(event_time_dummies) <- paste0("event_time_", c("m5","m4","m3","m2","m1",0,1,2,3,4))
simulated_data <- cbind(simulated_data, event_time_dummies)

# Multiply event-time dummies by treated
interaction_terms <- as.data.frame(event_time_dummies * simulated_data$treated)
colnames(interaction_terms) <- paste0(colnames(event_time_dummies), "_treated")

# Add interaction terms to the dataset
simulated_data <- cbind(simulated_data, interaction_terms)

# Event study regression (excluding event time = -1 as baseline)
event_study_model <- feols(
  blood_pressure ~
    event_time_m5_treated+
    event_time_m4_treated+
    event_time_m3_treated+
    event_time_m2_treated+
    event_time_0_treated+
    event_time_1_treated+
    event_time_2_treated+
    event_time_3_treated+
    event_time_4_treated | district + time,
  data = simulated_data
)

# Summary of the event study model
summary(event_study_model)




# Extract coefficients and confidence intervals for visualization
event_study_results <- broom::tidy(event_study_model, conf.int = TRUE) %>%
  filter(str_detect(term, "event_time")) %>%
  mutate(
    event_time = str_extract(term, "m?\\d+"),  # Extract the number with or without 'm'
    event_time = ifelse(str_detect(event_time, "m"),  # Check if 'm' is present
                        as.numeric(str_replace(event_time, "m", "-")),  # Replace 'm' with '-' and convert
                        as.numeric(event_time))  # Otherwise, convert directly to numeric
  )

# Plot the event study results
ggplot(event_study_results, aes(x = event_time, y = estimate)) +
  geom_point() +
  geom_line() +
  geom_errorbar(aes(ymin = conf.low, ymax = conf.high), width = 0.2) +
  geom_vline(xintercept = -1, linetype = "dashed", color = "red") +
  scale_x_continuous(breaks = c(-5:4))+
  labs(
    title = "Event Study: Impact of Intervention on Blood Pressure",
    x = "Event Time (Relative to Intervention Start)",
    y = "Effect on Blood Pressure"
  ) +
  theme_minimal()

 
 


