# Simulated Blood Pressure Analysis with Intervention Effects

 
# Load necessary libraries
library(dplyr)
library(ggplot2)
library(fixest)

# Parameters
set.seed(123)  # For reproducibility
num_districts <- 10
time_periods <- 10
intervention_start <- 6
intervention_effect <- -10
base_mean_bp <- 145
random_sd <- 5  # Standard deviation for random intercepts
time_fixed_effects <- seq(-2, 2, length.out = time_periods)  # Fixed effects for each time point

# Generate random intercepts for districts
districts <- 1:num_districts
random_intercepts <- rnorm(num_districts, mean = base_mean_bp, sd = random_sd)

# Assign intervention to 5 districts randomly
intervention_districts <- sample(districts, size = 5)

# Create the dataset
simulated_data <- expand.grid(
  district = districts,
  time = 1:time_periods
) %>%
  mutate(
    random_intercept = random_intercepts[district],
    time_fixed_effect = time_fixed_effects[time],
    intervention = ifelse(district %in% intervention_districts & time >= intervention_start, 1, 0),
    effect = intervention * intervention_effect,
    blood_pressure = random_intercept + time_fixed_effect + effect + rnorm(n(), mean = 0, sd = 2)  # Add noise
  ) %>%
  group_by(district) %>%
  mutate(
    treated = ifelse(-10 %in% effect, 1, 0),
    post = ifelse(time >= intervention_start, 1, 0)
  )

# Visualize overall data
ggplot(simulated_data, aes(x = time, y = blood_pressure, color = as.factor(treated), group = district)) +
  geom_line() +
  labs(
    title = "Simulated Blood Pressure Data with Time Fixed Effects",
    x = "Time",
    y = "Blood Pressure",
    color = "Treated"
  ) +
  theme_minimal()

# Focused comparison for 2 districts
simulated_data_bi <- simulated_data %>% filter(district %in% c(1, 6))

ggplot(simulated_data_bi, aes(x = time, y = blood_pressure, color = as.factor(treated), group = district)) +
  geom_line() +
  geom_point() +
  geom_vline(xintercept = 5.5, lty = 2) +
  labs(
    title = "Simulated Blood Pressure Data - 2 Districts",
    x = "Time",
    y = "Blood Pressure",
    color = "Treated"
  ) +
  theme_minimal()

# Two-way fixed effects (TWFE) model
model <- feols(blood_pressure ~ intervention | district + time, data = simulated_data_bi)
summary(model)

# Predict counterfactuals
simulated_data_bi_tc2 <- simulated_data_bi %>%
  filter(treated == 1, time >= 6) %>%
  mutate(intervention = 0)

simulated_data_bi_tc2$yc <- predict(model, newdata = simulated_data_bi_tc2)

# Visualize counterfactuals
ggplot(simulated_data_bi, aes(x = time, y = blood_pressure, color = as.factor(treated), group = district)) +
  geom_line() +
  geom_point() +
  geom_line(aes(x = time, y = yc, group = district), data = simulated_data_bi_tc2, lty = 2) +
  geom_point(aes(x = time, y = yc, group = district), shape = 21, data = simulated_data_bi_tc2) +
  geom_vline(xintercept = 5.5, lty = 2) +
  labs(
    title = "Simulated Blood Pressure Data - 2 Districts with Counterfactuals",
    x = "Time",
    y = "Blood Pressure",
    color = "Treated"
  ) +
  theme_minimal()

# Analyze differences in counterfactuals
b <- simulated_data_bi_tc2 %>%
  group_by(district) %>%
  summarise(
    y = mean(blood_pressure),
    yc = mean(yc)
  ) %>%
  mutate(difference = y - yc)

mean(b$difference)

# Full model for all districts
model <- feols(blood_pressure ~ intervention | district + time, data = simulated_data)
summary(model)

# Counterfactuals for all treated districts
simulated_data_bi_tc3 <- simulated_data %>%
  filter(treated == 1, time >= 6) %>%
  mutate(intervention = 0)

simulated_data_bi_tc3$yc <- predict(model, newdata = simulated_data_bi_tc3)

# Visualize full data with counterfactuals
ggplot(simulated_data, aes(x = time, y = blood_pressure, color = as.factor(treated), group = district)) +
  geom_line() +
  geom_line(aes(x = time, y = yc, group = district), data = simulated_data_bi_tc3, lty = 2) +
  geom_point(aes(x = time, y = yc, group = district), shape = 21, data = simulated_data_bi_tc3) +
  geom_vline(xintercept = 5.5, lty = 2) +
  labs(
    title = "Simulated Blood Pressure Data - 10 Districts with Counterfactuals",
    x = "Time",
    y = "Blood Pressure",
    color = "Treated"
  ) +
  theme_minimal()

